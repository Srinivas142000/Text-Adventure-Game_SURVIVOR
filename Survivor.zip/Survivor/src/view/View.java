package view;

import java.util.Vector;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import model.*;
import controller.*;

public class View {
	TimeUnit tu;
	CommonHelpers ch = new CommonHelpers();
	Constants C = new Constants();
	/*
	 * This method uses time unit to display each of line of string with 1 second delay for 
	 * user's convenience, this will be used as a common method for displaying all stories
	 * */
	
	public void initialStory(String [] story) throws InterruptedException{
		for (int i = 0; i < story.length; i++) {
				System.out.println(story[i]);
				tu.SECONDS.sleep(1);
			}
		}
	
	
	/*
	 * this method prints the story related to the tile that user lands on
	 * */
	
	public void printTileStory (String tile) throws InterruptedException {
		String [] currentStory;
		if (tile.toLowerCase().equals("snake") || tile.toLowerCase().equals("storm")) {
			currentStory = C.tileStory;
			currentStory[0] += tile;
			initialStory(currentStory);
		} else if (tile.toLowerCase().equals("quick sand")) {
			currentStory = C.moveBackStory;
			currentStory[0] += tile;
			initialStory(currentStory);
		} else if (tile.toLowerCase().equals("hill")) {
			initialStory(C.hillStory);
		}else if (tile.toLowerCase().equals("oasis")) {
			initialStory(C.oasisStory);
		} else {
			initialStory(C.safeStory);
		}
		tile = "";
	}
	
	/*
	 * this method displays the message to the user in case the current pointer moves out of array position
	 * usually if the pointer moves out of the position we would encounter array out of bounds exception 
	 * this method allows us to print a story and get the user back to the same position as before.
	 * */
	public void printOutofMapWarning() throws InterruptedException {
		initialStory(C.outOfBounds);
	}
	
	/*
	 * This method prints out a list of items in the bag */
	
	public void getInventory(Vector <String> Bag) {
		System.out.println("Items in Bag:");
		for (int i = 0; i < Bag.size(); i++) {
			System.out.println(Bag.get(i));
		}
	}
	
	/*
	 * This method prints the story for user if they decide to encounter the challenge 
	 * they face on the tile
	 * */
	
	public void encounterStory(String tile) throws InterruptedException{
		C.attackStory[0] += tile;
		initialStory(C.attackStory);
	}
	
	/*
	 * This method prints the story for user if they decide to escape the challenge 
	 * they face on the tile
	 * */
	
	public void escapeStory(String tile) throws InterruptedException{
		C.escapeStory[0] += tile;
		initialStory(C.escapeStory);
	}
	
	/*
	 * This method prints message if bag is full of items
	 * */
	
	public void bagMessages() {
		ch.printColor("Bag is full!!", C.color_bag);
	}
	
	/*
	 * This method is used to print general in-game messages for the user.
	 * */
	
	public void message (String msg) {
		System.out.println(msg);
	}
	
	/*
	 * This method is used to print the game exit message.
	 * */
	
	public void exit() {
		System.out.println("You have Exited the game!");
	}

	/* 
	 * This method is used to print the map for user to indicate the tiles they have traveled. 
	 * To prevent looping and printing used a resource i found online.
	 * To Print Map at once instead of running it in for loop i used this method
	 * https://stackoverflow.com/questions/2397535/how-to-print-two-dimensional-array-of-strings-as-string
	 *  */
	public void mapView(String [][] map) {
		ch.printColor(Arrays.deepToString(map[1]), C.color_map);
		ch.printColor(Arrays.deepToString(map[0]), C.color_map);
	}
	
	/*
	 * This method is used to print issues with user's input
	 * */
	
	public void issues() {
		System.out.println("Issue with Input - Verify the text / try another version");
	}
}
