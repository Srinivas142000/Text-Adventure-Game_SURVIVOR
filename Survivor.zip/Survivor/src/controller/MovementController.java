package controller;
import model.*;
import view.*;
import java.util.Vector;

public class MovementController {
	Model m = new Model ();
	View v = new View();
	public int Xbound_upper = 2;
	public int Xbound_lower = -1;
	public int Ybound_upper = 10;
	public int Ybound_lower = -1;
	public MovementController () {
		// Do nothing for now
	}
	
	/*
	 * This method uses the input to perform the specific actions users asks the game to verify
	 * */
	
	public void checkActions(Vector<String> words, Vector<String> bag, Player P) {
		for (int i = 0; i < words.size(); i ++) {
			String curr_word = words.get(i);
			if (curr_word.toLowerCase().equals("bag")) {
				v.getInventory(bag);
			} else if (curr_word.toLowerCase().equals("map")) {
				v.mapView(P.playerMap);
			} else if (curr_word.toLowerCase().equals("stamina")) {
				String resp = Double.toString(P.getStamina());
				v.message("Your Current Stamina is " + resp);
			} else if (curr_word.toLowerCase().equals("health")) {
				String resp = Double.toString(P.getHealth());
				v.message("Your Current Health is " + resp);
			}
		}
	}
	
	
	/*
	 * This method uses the input to move the user
	 * in the map, if the array position is increased more than the limits we print a story and bring back the user to the previous position
	 * */
	
	public void moveCharacter(Vector<String> words, Player p) throws InterruptedException {
		p.decreaseStamina(5);
		for (int i = 0; i < words.size(); i ++) {
			String curr_word = words.get(i);
			if (curr_word.toLowerCase().equals("right")) {
				p.userY += 1;
				if (p.userY >= Ybound_upper) {
					p.userY -= 1;
					v.printOutofMapWarning();
				}
				if (p.userY <= Ybound_lower) {
					p.userY += 1;
					v.printOutofMapWarning();
				}
			} else if (curr_word.toLowerCase().equals("left")) {
				p.userY -= 1;
				if (p.userY >= Ybound_upper) {
					p.userY -= 1;
					v.printOutofMapWarning();
				}
				if (p.userY<= Ybound_lower) {
					p.userY += 1;
					v.printOutofMapWarning();
				}
			} else if (curr_word.toLowerCase().equals("forward") || curr_word.toLowerCase().equals("up")) {
				p.userX += 1;
				if (p.userX <= Xbound_lower) {
					p.userX += 1;
					v.printOutofMapWarning();
				}
				if (p.userX >= Xbound_upper) {
					p.userX -= 1;
					v.printOutofMapWarning();
				}
			} else if (curr_word.toLowerCase().equals("back") || curr_word.toLowerCase().equals("down")) {
				p.userX-= 1;
				if (p.userX >= Xbound_upper) {
					p.userX -= 1;
					v.printOutofMapWarning();
				}
				if (p.userX <= Xbound_lower) {
					p.userX += 1;
					v.printOutofMapWarning();
				}
			}
		}
	}
}
