package controller;

import java.util.Scanner;
import java.util.Vector;
import model.*;
import view.*;

public class Controller {
	String[] story = new String [] {"You are stranded in a desert!!!!", "You are bruised!", "You look at your surroundings..... and you see mounds of sand all around you", "You check yourself and find a bag with you.."};
	String [] menu = new String [] {"Welcome to the Survivor Game!!!\n", "Each step consumes stamina", "The objective is to reach the settlement before before your stamina and health run out", "Enter \'Quit\' in between the story to quit or \'S\' to Start"};
	Scanner input;
	MovementController MC = new MovementController();
	CommonHelpers CH = new CommonHelpers();
	Player P = new Player();
	Model model;
	View view;
	Constants c = new Constants();
	
	public Controller(Model m, View v) {
		this.model = m;
		this.view = v;
		input = new Scanner(System.in);
	}
	
	/*
	 * this method uses a item in the bag and it's respective attributes to player
	 * if the return is true, it means the item is consumed else it is not consumed
	 * */
	
	public boolean useItem(String Item, Player Pl) {;
		Vector<String> words = CH.breakSentence(Item);
		for (String w: words) {
			if (w.toLowerCase().equals("water")) {
				Pl.stamina += 5;
				Pl.health += 10;
				return true;
			}
			if (w.toLowerCase().equals("electrolytes")) {
				Pl.stamina += 10;
				Pl.health += 5;
				return true;
			}
		}
		return false;
	}
	
	/*
	 * this method stores an item in the bag 
	 * if the return is true, it means the item is stored else it is not stored
	 * */
	
	public boolean storeItems(Vector <String> words, Vector <String> Bag) {
		if (Bag.size() > 10) {
			view.bagMessages();
			return false;
		} else {
			for(int i =0; i<words.size(); i++)
			{
				String word = words.get(i);
				if (!word.toLowerCase().equals("preserve") || !word.toLowerCase().equals("store")) {
					if (word.toLowerCase().equals("water")) {
						boolean added = model.addItems(Bag, "Water - Adds 10 health and 5 stamina");
						if  (!added) {
							view.message("Bag is full, unable to add items");
						}
					} else if (word.toLowerCase().equals("food") || word.toLowerCase().equals("rations")) {
						boolean added = model.addItems(Bag, "Rations - Adds 5 health");
						if  (!added) {
							view.message("Bag is full, unable to add items");
						}
					}
				}
			}
			return true;
		}
	}
	
	/*
	 * this method uses a item in the bag and it's respective attributes to player
	 * if the return is true, it means the item is consumed else it is not consumed
	 * depending on the item, we need to remove it from bag.
	 * */
	
	public boolean useItems(Vector <String> words, Vector <String> Bag) {
		for (String S: words) {
			for (int i = 0; i < Bag.size(); i++) {
				String bagitem = Bag.get(i);
				Vector<String> bag_break = CH.breakSentence(bagitem);
				for (String S1: bag_break) {
					if (S.toLowerCase().equals(S1.toLowerCase())) {
						boolean used = useItem(bagitem, P);
						if (used) {
							Bag.remove(i);
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	/*
	 * gets string breaks it into words checks the vector of strings to find 
	 * common words and matches them with switch case
	 * */
	
	public int parser(String userInp) {
		Vector <String> words = CH.breakSentence(userInp);
	    for (int i = 0; i < words.size(); i++ ) {
	    	String w = words.get(i).toString();
	    	if (w.toLowerCase().equals("move")) {
	    		System.out.println("move");
	    		return 1;
	    	} else if (w.toLowerCase().equals("encounter") || w.toLowerCase().equals("attack")) {
	    		System.out.println("encounter");
	    		return 2;
	    	} else if (w.toLowerCase().equals("check") || w.toLowerCase().equals("show") || w.toLowerCase().equals("get") || w.toLowerCase().equals("see")) {
	    		System.out.println("check");
	    		return 3;
	    	} else if (w.toLowerCase().equals("replenish") || w.toLowerCase().equals("store")) {
	    		System.out.println("replenished");
	    		return 4;
	    	} else if (w.toLowerCase().equals("use") || w.toLowerCase().equals("drink")) {
	    		System.out.println("used");
	    		return 5;
	    	} else if (w.toLowerCase().equals("run") || w.toLowerCase().equals("escape") || w.toLowerCase().equals("run")) {
	    		System.out.println("ran");
	    		return 6;
	    	} else if (w.toLowerCase().equals("cannot") || w.toLowerCase().equals("donot") || w.toLowerCase().equals("wouldnot") || w.toLowerCase().equals("shallnot") || w.toLowerCase().equals("willnot") ||
	    			w.toLowerCase().equals("won't") || w.toLowerCase().equals("don't") || w.toLowerCase().equals("shalln't") || w.toLowerCase().equals("ain't")) {
	    		System.out.println("Negative sentiment detected");
	    		return 10;
	    	}
	    }
	    return 0;
	}
	
	/*
	 * runGame - runs the method to start the game, depending upon the game 
	 * position we print the tile story.
	 * */
 	public void runGame() throws Exception {
		view.initialStory(menu);
		String inp;
		inp = input.nextLine();
		if (inp.equals("S")) {
			view.initialStory(story);
			do {
				inp = input.nextLine();
				int num = parser(inp);
				Vector <String> wordsAr = CH.breakSentence(inp);
				int positionX = P.getX();
				int positionY = P.getY();
				num = parser(inp);
				wordsAr = CH.breakSentence(inp);
				if (positionX == -1) {
					positionX +=1;
				}
				if (positionY == -1) {
					positionY +=1;
				}
				if (num > 0) {
					if (P.getStamina() < 0 || P.getHealth() < 0 ) {
						CH.printColor(c.game_over, c.color_danger);
						inp = "Quit";
						break;
					}
					if (c.GameMap[positionX][positionY].toLowerCase().equals("finish")) {
						P.playWinnerFare();
						inp = "Quit";
						break;
					}
					if (num == 1) {
						view.printTileStory(c.GameMap[positionX][positionY]);
						P.playerMap[positionX][positionY] = c.GameMap[positionX][positionY];
						MC.moveCharacter( wordsAr, P);
					} else if (num == 2) {
						P.attack();
						view.encounterStory(c.GameMap[positionX][positionY]); 
					} else if (num == 3) {
						MC.checkActions(wordsAr, P.bag , P);
					} else if (num == 4) {
						if (c.GameMap[positionX][positionY].toLowerCase().equals("oasis")) {
				    		boolean didStore = storeItems(wordsAr, P.bag);
				    		if (didStore) {
								System.out.println("Stored item");
				    		}
						} else {
							view.message("You cannot store any items in the current position, you can only store items in a Oasis");
						}
					} else if (num == 5) {
			    		boolean didStore = useItems(wordsAr, P.bag);
			    		if (didStore) {
							System.out.println("Used item");
			    		}
					} else if (num == 6) {
			    		view.escapeStory(c.GameMap[positionX][positionY]);
			    		MC.moveCharacter( wordsAr, P);
						view.printTileStory(c.GameMap[positionX][positionY]);
						P.playerMap[positionX][positionY] = c.GameMap[positionX][positionY];
					} else if (num == 10) { 
			    		view.initialStory(c.negativeSentiment);
					} else {
						view.issues();
					}
				} else {
					view.issues();
				}
			} while (inp != "Quit");
			view.exit();
		}
	}
	
}
