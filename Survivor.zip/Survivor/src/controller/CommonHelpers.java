package controller;
import java.util.Vector;

import model.*;


public class CommonHelpers {
	Constants c = new Constants();
	
	
	/* Thought printing game prompts in multiple colors would make it interesting 
	 * Used this resource to print console statements
	 * https://stackoverflow.com/questions/32573654/is-there-a-way-to-create-an-orange-color-from-ansi-escape-characters
	*/
	public void printColor(String message, String color_warning) {
		System.out.println(color_warning + message + c.color_reset);
	}
	
	/*
	 * This method uses a string in which words are separated by spaces to break them up and return them as a vector of words
	 * */
	
	public Vector<String> breakSentence(String userInp) {
		Vector <String> words = new Vector<>();
	    String t = "";
	    for (int i = 0; i < userInp.length(); i++) {
	        if (userInp.charAt(i) == ' ') {
	            if (!t.isEmpty()) {
	                words.add(t);
	                t = "";
	            }
	        } else {
	            t += userInp.charAt(i);
	        }
	    }
	    words.add(t);
	    return words;
	}
}
