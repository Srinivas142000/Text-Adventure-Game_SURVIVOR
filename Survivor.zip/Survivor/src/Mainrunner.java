import model.*;
import java.util.Vector;
import controller.*;
import view.*;

public class Mainrunner {
	public static void main(String [] args) throws Exception{
		Model M = new Model();
		View V = new View();
		Controller C = new Controller(M,V);
		C.runGame();
	}
}
