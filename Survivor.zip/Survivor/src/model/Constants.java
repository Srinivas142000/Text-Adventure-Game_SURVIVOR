package model;

/*
 * This class contains all the constant values involved in the game, this way we can change it here 
 * and expect changes in the project.
 * */

public class Constants {
	public static final String color_warning = "\u001B[33m";
	public static final String color_danger = "\u001B[41m";
	public static final String color_bag = "\u001B[32m";
	public static final String color_reset = "\u001B[0m";
	public static final String color_win = "\u001B[34m";
	public static final String color_map = "\033[0;37m";
	public static final String [][] GameMap = {
											{"Oasis", "Quick Sand", "Storm", "Safe", "Snake", "Snake", "Safe", "Hill", "Safe", "Storm"},
											{"Snake", "Safe", "Safe", "Safe", "Snake", "Oasis", "Storm", "Safe", "Hill", "Finish"}
										  };
	public static final String[] tileStory = new String [] {"You Encounter a ", "You have an option to Encounter it or Run", "If you run your stamina will decrease by 15", "If you encounter it your health will decrease by 10 and stamina will decrease by 5", "If you wish to run indicate the direction or wish to encounter it"};
	public static final String[] moveBackStory = new String [] {"You Encountered a ", "You have an option to Encounter it or move to another adjacent space", "If you run your stamina will decrease by 15", "If you encounter it your health and stamina will decrease", "If you wish to move indicate the direction"};
	public static final String[] safeStory = new String [] {"You are in a safe space", "You can move or use items in your bag", "If you are in a Oasis you can replenish your supplies"};
	public static final String[] outOfBounds = new String [] {"You move into the space", "You realise you are lost....", "You go back to the original place from where you started."};
	public static final String[] attackStory = new String [] {"Being a brave soul, you decided to encounter the ", "But it came at a price", "Your vitals are impacted"};
	public static final String[] oasisStory = new String [] {"You've reached the Oasis, you can replenish your supplies", "You can store food which give you 5 stamina or water which give you 5 health and 5 stamina"};
	public static final String[] escapeStory = new String [] {"Being a clever soul, you decided to escape the ", "But it came at a price", "Your vitals are impacted"};
	public static final String game_over = "☠️☠️☠️ You tried and couldn't reach the settlement ☠️☠️☠️";
	public static final String[] hillStory = new String [] {"You've reached a hill, although this is a safe spot your stamina will be consumed to cross this tile"};
	public static final String[] negativeSentiment = new String [] {"The heat is getting to you", "You are confused", "You have a long debate in your mind and motivate yourself", "Finally you decide to have can do attitude"};
}
