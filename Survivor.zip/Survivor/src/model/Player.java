package model;
import controller.*;
import view.*;
import java.util.Vector;
import java.util.Random;

public class Player {
	public String name;
	CommonHelpers ch = new CommonHelpers();
	Constants c = new Constants();
	Model model = new Model();
	View v = new View();
	Random r = new Random();
	public Vector<String> bag = new Vector<>(10);
	public String [][] playerMap = {{null, null, null, null, null, null, null, null, null, null},{null, null, null, null, null, null, null, null, null, null}};
	
	/*
	 * Player Constructor - adds the two items in the bag for each player
	 * */
	public Player () {
		boolean item = model.addItems(bag, "Water - Adds 10 health and 5 stamina");
		boolean item1 = model.addItems(bag, "Electrolytes - Adds 5 health and 10 stamina");
	}
	public double health = 100, stamina = 100;
	public int userX = 0, userY = 0;
	
	/*
	 * method uses the Player Object and decreases the health
	 * */
	
	public void decreaseHealth(double hp) {
		this.health -= hp;
	}
	
	/*
	 * Plays winner message at the end of the game if player reaches settlement
	 * */
	
	public void playWinnerFare() {
		ch.printColor("🎉🎉🎉🎉🎉 Congrats!!! You've reached settlement 🎉🎉🎉🎉🎉", c.color_win);
	}
	
	/*
	 * gets player's X coordinate
	 * */
	public int getX() {
		return this.userX;
	}
	
	/*
	 * gets player's Y coordinate
	 * */
	public int getY() {
		return this.userY;
	}
	
	/*
	 * method uses the Player Object and decreases the stamina
	 * */
	
	public void decreaseStamina(double s) {
		this.stamina -= s;
	}
	
	
	
	/*
	 * Roll Dice to see if damage applied to player is high or low
	 * If roll is > 4 decrease only stamina else decrease a big chunk of stamina and health
	 * */
	
	public void attack() {
		int diceRoll = r.nextInt(1,6);
		if (diceRoll > 4) {
			v.message("You successfullly manage to attack it and escape with no damage at all !!!");
			decreaseStamina(15);
		} else {
			v.message("You manage to attack it, but do more damage to yourself in this process !!!");
			decreaseStamina(25);
			decreaseHealth(20);
		}
	}
	
	/*
	 * get's player's current health and prints warning messages accordingly
	 * */
	
	public double getHealth() {
		if (this.health < 10) {
			ch.printColor("Your health is running out!", c.color_danger);
		} else if (this.health < 50) {
			ch.printColor("Your health is running out!", c.color_warning);
		}
		return this.health;
	}
	
	/*
	 * get's player's current stamina and prints warning messages accordingly
	 * */
	
	public double getStamina() {
		if (this.stamina < 50) {
			ch.printColor("Your stamina is running out!", c.color_warning);
		}
		return this.stamina;
	}
}
