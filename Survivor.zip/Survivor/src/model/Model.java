package model;

import java.util.Vector;



public class Model {
	int inv_size = 10;
	int index = 0;
	/* 
	 * Fetches the current index of the item or number of items in bag
	 * */
	public int getItemsInBag() {
		return this.index;
	}
	
	/* 
	 * Fetches the current index of the item or number of items in bag
	 * and adds items into the bag
	 * */
	public boolean addItems(Vector<String> Bag, String item) {
		if (Bag.size() >= 10) {
			return false;
		} else {
			Bag.add(item);
			return true;
		}
		
	}

	/* 
	 * gets the item from the bag
	 * */
	public String fetchItem(Vector<String> bag, int index) {
		return bag.get(index);
	}
}

